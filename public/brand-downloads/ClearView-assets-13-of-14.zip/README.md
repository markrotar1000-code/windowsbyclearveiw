# ClearView Windows and Trim brand package

Finish: subdued satin cobalt, pewter and graphite, with the approved clean lettering.

## Start here
- masters/clearview-transparent.png: full logo for LIGHT backgrounds.
- masters/clearview-on-white.png or .jpg: full logo with white background.
- masters/clearview-emblem-transparent.png: standalone emblem.
- facebook/profile-1080.png: Facebook profile upload; generous circular crop room.
- facebook/cover-1702x630.png: primary cover upload, 2x the 851x315 layout.
- facebook/cover-flexible-1640x720.png: taller alternative for crop adjustment.
- web/: PNG, WebP and AVIF exports for websites.
- icons/: square sizes and multi-resolution ICO.
- print/: transparent TIFF, PDF and EPS.

## Format limits
The detailed scenic master is RASTER artwork. The SVG contains an embedded PNG;
PDF and EPS also contain raster artwork. None is a native vector tracing or an
editable Adobe Illustrator file. No AI, layered PSD, Pantone or embroidery file
is claimed. A production vector/embroidery simplification needs separate artwork.
TIFF and PDF use 300-PPI physical sizing at native resolution; no invented 4K detail.
All colors are RGB/sRGB. Ask a printer for an ICC-managed CMYK conversion if needed.
The transparent navy wordmark is intended for white/light backgrounds. Use the
white-background version on dark layouts, or the emblem with live light text as
the website does. Keep aspect ratios unchanged and leave clear space around it.

## Social crop and upload
Use PNG for crisp lettering. Facebook crops images differently across layouts;
check both desktop and phone previews before saving. The cover puts its content
near the center and keeps the lower portion clear. The profile uses the emblem
alone so small circular crops do not turn the company name into unreadable text.
These files are prepared for upload; this package does not itself publish them.

## Source history
The source approved in chat was clearview-windows-and-trim-type-v5.png. The owner
then requested less shine on both the logo and Facebook cover. These final exports
use that softer finish. Earlier iterations remain outside this package.
